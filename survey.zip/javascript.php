	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>framework/js/jquery-2.1.0.min.js"></script>
	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>framework/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>framework/owl/dist/owl.carousel.min.js"></script>
	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>framework/js/framework.js"></script>
	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>assets/js/custom.js"></script>
	<script type="text/javascript" src="<?php echo $protocol . $rootpath . "/" ?>framework/js/functions.js"></script>