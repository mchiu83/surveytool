<?php
require("config.php");
$SITE_ID = $_GET['id'];
$TYPE = $_GET['type'];

switch($TYPE){
	case "summary":
		$query = "SELECT phones.phone_id, phones.Directory_Number, phones.NAME_on_directory_number, phones.TYPE TYPE_OLD, phone_updates.type AS TYPE_NEW, phone_updates.room as ROOM_ID, phone_updates.dept, phone_updates.phonename, phone_updates.firstname, phone_updates.lastname, phone_updates.wallmount, phone_updates.dualhandset, phone_updates.note AS NOTES FROM phones LEFT JOIN phone_updates ON phones.phone_id = phone_updates.phone_id WHERE phones.site_id = $SITE_ID";
	break;
	default:
}


// filename for export
$csv_filename = 'summary_'.date('Y-m-d').'.csv';
// database variables

// create empty variable to be filled with export data
$csv_export = '';

// query to get data from database
$query = mysqli_query($con, $query);
$field = mysqli_field_count($con);

// create line with field names
for($i = 0; $i < $field; $i++) {
    $csv_export.= mysqli_fetch_field_direct($query, $i)->name.',';
}

// newline (seems to work both on Linux & Windows servers)
$csv_export.= '
';

// loop through database query and fill export variable
while($row = mysqli_fetch_array($query)) {
    // create line with field values
    for($i = 0; $i < $field; $i++) {
        $csv_export.= '"'.$row[mysqli_fetch_field_direct($query, $i)->name].'",';
    }
    $csv_export.= '
';
}

// Export the data and prompt a csv file for download
header("Content-type: text/x-csv");
header("Content-Disposition: attachment; filename=".$csv_filename."");
echo($csv_export);
?>