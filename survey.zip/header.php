<!DOCTYPE HTML>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui"/>
	<meta name="apple-mobile-web-app-capable" content="yes"/>
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo $protocol . $rootpath . "/" ?>framework/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $protocol . $rootpath . "/" ?>framework/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $protocol . $rootpath . "/" ?>framework/owl/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $protocol . $rootpath . "/" ?>assets/css/style.css">
</head>
<body class="double-menu">

<!-- Page Pre-loader -->
<div class="cat-loading">
	<div class="cat-frame"></div>
	<h3 class="loading-text">loading ...</h3>
	<img class="loading-logo" src="<?php echo $protocol . $rootpath . "/" ?>assets/img/logo.svg">
</div>