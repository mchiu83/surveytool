<?php

require("config.php");

$user_id = $_SESSION['id'];

$action = $_GET['action'];
$sitename = $_GET['sitename'];
$sitename = strtolower($sitename);
$siteid = $_GET['siteid'];
$phoneid = $_GET['phoneid'];
$phonename = $_GET['phonename'];
$firstname = $_GET['firstname'];
$lastname = $_GET['lastname'];
$dept = $_GET['dept'];
$room = $_GET['room'];
$voicemail = $_GET['voicemail'];
$wallmount = $_GET['wallmount'];
$dualhandset = $_GET['dualhandset'];
$cable = $_GET['cable'];
$type = $_GET['phonetype'];
$notes = $_GET['notes'];

$firstname = empty($firstname) ? null : $firstname;
$lastname = empty($lastname) ? null : $lastname;
$room = empty($room) ? null : $room;
$dept = empty($dept) ? null : $dept;
$notes = empty($notes) ? null : $notes;

if($_SESSION['permission'] == "Viewer")
{
	echo "You have view permissions only!";
} else {
	if($action == "update" && !isset($_FILES['myFile'])) {
		$sql = "SELECT thumb_url, photo_url FROM phone_updates WHERE site_id = $siteid AND phone_id = $phoneid";
		$result = mysqli_query($con,$sql);
		while($row = mysqli_fetch_assoc($result)) {
			$old_photo_url = $row['photo_url'];
			$old_thumb_url = $row['thumb_url'];
		}
	}

	if (isset($_FILES['myFile'])) {
		
		$file_thumb = $_FILES['myFile']['tmp_name']; 
		$file_gallery = $_FILES['myFile']['tmp_name'];
		$sourceProperties_thumb = getimagesize($file_thumb);
		$sourceProperties_gallery = getimagesize($file_gallery);
		$fileNewName = time();
		$folderPath = "site_photo/" . $sitename . "/";

		$imageType = $sourceProperties_thumb[2];
		
		$imageResourceId_thumb = imagecreatefromjpeg($file_thumb); 
		$thumbnail = imageResizeThumb($imageResourceId_thumb,$sourceProperties_thumb[0],$sourceProperties_thumb[1]);
		imagejpeg($thumbnail,$folderPath. $fileNewName. "_thumb.jpg");
		move_uploaded_file($file, $folderPath. $fileNewName. "_thumb.jpg");
		$thumb_url = $protocol . $rootpath . "/" . $folderPath . $fileNewName . "_thumb.jpg";
		
		$imageResourceId_gallery = imagecreatefromjpeg($file_gallery);
		$gallery = imageResizeGallery($imageResourceId_gallery,$sourceProperties_gallery[0],$sourceProperties_gallery[1]);
		imagejpeg($gallery,$folderPath. $fileNewName. "_gallery.jpg");
		move_uploaded_file($file, $folderPath. $fileNewName. "_gallery.jpg");
		$photo_url = $protocol . $rootpath . "/" . $folderPath . $fileNewName . "_gallery.jpg";
	} else {
		$thumb_url = "https://via.placeholder.com/300x250?text=Survey+Me";
		$photo_url = "https://via.placeholder.com/600x350?text=Upload+Photo";
	}

	switch($action){
		case "add":
			$sql = "INSERT INTO phone_updates (site_id, phone_id, phonename, dept, room, firstname, lastname, voicemail, wallmount, cable, dualhandset, type, thumb_url, photo_url, note) " . 
					"VALUES($siteid, $phoneid,'$phonename','$dept','$room','$firstname','$lastname',$voicemail,$wallmount,$cable,$dualhandset, '$type','$thumb_url','$photo_url','$notes')";
			if(mysqli_query($con, $sql)){
				$audit_description = "Assigned survey data as " . $phonename . " for " . $room . " with Cisco " . $type;
				$action = ucwords($action);
				$sql = "INSERT INTO phone_audit (site_id, phone_id, action, user_id, description) " .
						"VALUE ($siteid, $phoneid, '$action', $user_id, '$audit_description') ";
				mysqli_query($con, $sql);
				echo "add okay";
			} else {
				echo "error";
			}
			break;
			
		case "delete":
			$sql = "DELETE FROM phone_updates WHERE site_id = '$siteid' AND phone_id = '$phoneid'";
			if(mysqli_query($con, $sql)){
				$audit_description = "Deleted survey data";
				$action = ucwords($action);
				$sql = "INSERT INTO phone_audit (site_id, phone_id, action, user_id, description) " .
						"VALUE ($siteid, $phoneid, '$action', $user_id, '$audit_description') ";
				mysqli_query($con, $sql);
				echo "delete okay";
			} else {
				echo "error";
			}
			break;
			
		case "update":
			if(!empty($old_photo_url)) {
				$thumb_url = $old_thumb_url;
				$photo_url = $old_photo_url;
			}
			$sql = "UPDATE phone_updates SET phonename = '$phonename', dept = '$dept', room = '$room', firstname = '$firstname', lastname = '$lastname', voicemail = $voicemail,
											wallmount = $wallmount,
											cable = $cable,
											dualhandset = $dualhandset,
											type = '$type',
											thumb_url = '$thumb_url',
											photo_url = '$photo_url',
											note = '$notes' WHERE site_id = $siteid AND phone_id = $phoneid";
			if(mysqli_query($con, $sql)){
				$audit_description = "Updated survey data for " . $phonename . " with Cisco " . $type;
				$action = ucwords($action);
				$sql = "INSERT INTO phone_audit (site_id, phone_id, action, user_id, description) " .
						"VALUE ($siteid, $phoneid, '$action', $user_id, '$audit_description') ";
				mysqli_query($con, $sql);

				echo "update okay";
			} else {
				echo "error";
			}
			break;		
		
		case "custom":
			$directory_number = date("ymdHms");
			$name_on_directory_number = $_SESSION['lastname'] . " Custom " . date("YmdHms");
			$sql = "INSERT INTO phones ( site_id, TYPE, Directory_Number, NAME_on_directory_number ) VALUES ($siteid, 999, $directory_number, '$name_on_directory_number')";

			if(mysqli_query($con, $sql)){
				$audit_description = "Custom added phone data as " . $name_on_directory_number . " for " . $room . " with Cisco " . $type;
				$action = ucwords($action);
				$sql = "SELECT phone_id from phones WHERE Directory_Number = $directory_number";
				$result = mysqli_query($con,$sql);
						while($row = mysqli_fetch_assoc($result)) {
							$phoneid = $row['phone_id'];
				}
				$sql = "INSERT INTO phone_updates (site_id, phone_id, phonename, dept, room, firstname, lastname, voicemail, wallmount, cable, dualhandset, type, thumb_url, photo_url, note) " . 
					"VALUES($siteid, $phoneid,'$phonename','$dept','$room','$firstname','$lastname',$voicemail,$wallmount,$cable,$dualhandset, '$type','$thumb_url','$photo_url','$notes')";
				if(mysqli_query($con, $sql)){
					$audit_description = "Assigned survey data as " . $phonename . " for " . $room . " with Cisco " . $type;
					$action = ucwords($action);
					$sql = "INSERT INTO phone_audit (site_id, phone_id, action, user_id, description) " .
							"VALUE ($siteid, $phoneid, '$action', $user_id, '$audit_description') ";
					mysqli_query($con, $sql);
					echo "custom okay";
				} else {
					echo "error 2";
				}
				
			} else {
				echo "error 1";
			}

			break;	
	}
}
$con -> close();

?>