<!-- left drawer menu -->
<div id="left-menu" class="drawer-menu left">
<div class="drawer-banner">
	<img class="img-responsive" src="<?php echo $protocol . $rootpath . "/" ?>assets/banner/banner.jpg">
	<div class="overlay"></div>
	<div class="user-info">
		<div class="img">
			<img src="<?php echo $protocol . $rootpath . "/" ?>assets/img/profile.png">
		</div>
		<div class="info">
			<p class="title"><?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></p>
			<p class="subtitle"><?php echo $_SESSION['email']; ?></p>
		</div>
	</div>
</div>
<div class="content">
	<ul>
		<li>
			<a  href="<?php echo $protocol . $rootpath; ?>">  <!-- id must be unique and must match with collapsible div -->
				<span class="ico"><i class="fa fa-home" aria-hidden="true"></i></span>
				Home
			</a>
		</li>
		<li>
			<div class="divider"></div>
			<li>
			<a  href="<?php echo $protocol . $rootpath . "/" . "profile.html"; ?>">  <!-- id must be unique and must match with collapsible div -->
				<span class="ico"><i class="fa fa-user" aria-hidden="true"></i></span>
				Profile
			</a>
			</li>
		</li>
		<li>
			<div class="divider"></div>
			<li>
				<a href="<?php echo $protocol . $rootpath . "/reset.html"; ?>">  <!-- id must be unique and must match with collapsible div -->
					<span class="ico"><i class="fa fa-sign-in" aria-hidden="true"></i></span>Reset Password
				</a>
			</li>
		</li>
	</ul>
</div>
</div>
<div class="drawer overlay"></div>